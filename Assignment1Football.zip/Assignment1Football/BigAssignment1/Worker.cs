﻿using System;
using Assignment1Football;

namespace BigAssignment1
{
    public class Worker
    {
        public void Start()
        {
            try
            {
                FootballPlayer player1 = new FootballPlayer(1, "Sonic", 1991, 15);
                string result = player1.PrintInfo();
                Console.WriteLine(result);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Invalid values detected! \nPlease make sure to input correct values!");
            }

            //FootballPlayer player2 = new FootballPlayer(3, "Big", 1999, 21);
            //string result2 = player2.PrintInfo();
            //Console.WriteLine(result2);
        }
    }
}
