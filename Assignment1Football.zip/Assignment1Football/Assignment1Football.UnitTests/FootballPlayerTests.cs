using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Assignment1Football.UnitTests
{
    [TestClass]
    public class FootballPlayerTests
    {
        private readonly FootballPlayer _sut;

        public FootballPlayerTests()
        {
            //Arrange
            _sut = new FootballPlayer();
        }

        [TestMethod]
        public void TestFootballPlayerName()
        {
            //Act
            _sut.Name = "Tails";

            //Assert
            Assert.AreEqual("Tails", _sut.Name);
        }

        [TestMethod]
        public void TestFootballPlayerPrice()
        {
            //Act
            _sut.Price = 1992;

            //Assert
            Assert.AreEqual(1992, _sut.Price);
        }

        [TestMethod]
        public void TestFootballPlayerShirtNumber()
        {
            //Act
            _sut.ShirtNumber = 8;

            //Assert
            Assert.AreEqual(8, _sut.ShirtNumber);
        }
    }
}
