﻿using System;

namespace BigAssignment1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Worker pleaseWork = new Worker();
            pleaseWork.Start();
            Console.WriteLine("Hello World");
        }
    }
}
